<?php
$q1 = $_POST['q1'];
$q2 = $_POST['q2'];
$q3 = $_POST['q3'];
$q4 = $_POST['q4'];
$q5 = $_POST['q5'];
$comentario = $_POST['comentario']

$host = 'localhost';
$username = 'sy';
$password = 'graden';
$dbname = 'pi';
$conn = mysqli_connect($host, $username, $password, $dbname);


if (!$conn) {
    die("Falha na conexão: " . mysqli_connect_error());
}


$sql = "INSERT INTO respostas (q1,q2, q3, q4, q5, 'comentario')
        VALUES ('$q1', '$q2', $q3, '$q4', '$q5', '$comentario')";

if (mysqli_query($conn, $sql)) {
    echo "Sucesso inserção";
} else {
    echo "falha ao inserir " . mysqli_error($conn);
}

/
mysqli_close($conn);
?>