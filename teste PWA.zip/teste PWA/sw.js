// const urlsToCache = [
//     '/',
//     '/index.html',
//     '/style.css',
//     '/app.js'
//   ];



// self.addEventListener('install', event => {
//     event.waitUntil(
//       caches.open('my-cache')
//       .then(cache => {
//         cache.addAll(urlsToCache)
//           .catch(error => {
//             console.error('Cache failed:', error);
//           });
//       }))
//   });
  
//   // Serve cached files if available, otherwise fetch them from the network
//   self.addEventListener('fetch', event => {
//     event.respondWith(
//       caches.match(event.request)
//         .then(response => {
//           if (response) {
//             return response;
//           } else {
//             return fetch(event.request)
//               .then(response => {
//                 // Cache the fetched response
//                 return caches.open('my-cache')
//                   .then(cache => {
//                     cache.put(event.request, response.clone());
//                     return response;
//                   });
//               });
//           }
//         })
//     );
//   });



// if (request.url.indexOf("chrome-extension") === -1){

// caches.open(pwatrial).then (function(cache){
//   console.log("caching : ",request.url);
//   cache.put(request,response.clone())
//   return response;
// });

// } else{
//   console.log("not caching:", request.url);
//   return response;
// }

// // fetch event
// self.addEventListener('fetch', evt => {
//   // check if request is made by chrome extensions or web page
//   // if request is made for web page url must contains http.
//   if (!(evt.request.url.indexOf('http') === 0)) return; // skip the request. if request is not made with http protocol

//   evt.respondWith(
//     caches
//       .match(evt.request)
//       .then(
//         cacheRes =>
//           cacheRes ||
//           fetch(evt.request).then(fetchRes =>
//             caches.open(pwatrial).then(cache => {
//               cache.put(evt.request.url, fetchRes.clone());
//               // check cached items size
//               limitCacheSize(dynamicNames, 75);
//               return fetchRes;
//             })
//           )
//       )
      
//   );
// });

self.addEventListener("install", (e) => {
  console.log("[Service Worker] Install");
});

const cacheName = "pwatrial";
const urlsToCache = [
    '/index.html',
    '/dddcss/style.css',
    'pwatrial.netlify.app',
  ];





  self.addEventListener("install", (e) => {
    console.log("[Service Worker] Install");
    e.waitUntil(
      (async () => {
        const cache = await caches.open("pwatrial");
        console.log("[Service Worker] Caching all: app shell and content");
        await cache.addAll(urlsToCache);
      })()
    );
  });




 
// cache size limit function
const limitCacheSize = (name, size) => {
  caches.open(name).then(cache => {
    cache.keys().then(keys => {
      if (keys.length > size) {
        cache.delete(keys[0]).then(limitCacheSize(name, size));
      }
    });
  });
}; 